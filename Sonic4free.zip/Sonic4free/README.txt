========================================================================================
Sonic the Hedgehog (sonic4free) (REV00) [Allsonic] - MAY 3rd 2021 Disassembly
========================================================================================
----------------------------------------------------------------------------------------
	                      What's Sonic4free?
----------------------------------------------------------------------------------------
Sonic4free is a modified june2005 (AS) version and not the others if im correct.
               And is apart of a project called AllSonic.
----------------------------------------------------------------------------------------
	                       What's AllSonic?
----------------------------------------------------------------------------------------
AllSonic is a project that tries to  be a edited version of Sonic 1,2,3&K
for now i just used guides and put them in the asm file since i can't code.
I mean AT ALL! but im just solo for this project for now. 
----------------------------------------------------------------------------------------
	                     How to compile a ROM
----------------------------------------------------------------------------------------
1.  Click on build.bat.
2.  The file Sonic0.1built.bin is your output ROM.
note: also, the main asm file is called: sonic4free.asm
----------------------------------------------------------------------------------------
	                            Credits
----------------------------------------------------------------------------------------
Disassembly by ZriseP0pOutMaster
----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------
	                         Oringinal  Credits
----------------------------------------------------------------------------------------
Disassembly by Hivebrain
Thanks: drx, Korama, Lightning, Magus, Nemesis, Stealth
----------------------------------------------------------------------------------------
Reminder - always make backups of your whole disassmebly!
Let me know if you have any problems with it.
Also, at the end of a act only shows you your score instead of all of them.